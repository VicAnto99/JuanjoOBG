﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class die : MonoBehaviour
{
    public bool alive;
    public GameObject halcon;
    // Start is called before the first frame update
    void Start()
    {
        alive = true;
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("You are dead");
        transform.position = new Vector3(-78.344f, 2.769f, 0f);
        alive = false;


    }



}