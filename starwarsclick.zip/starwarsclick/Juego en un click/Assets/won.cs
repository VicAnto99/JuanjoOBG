﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class won : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("You won");
        transform.position = new Vector3(-71.22f, -29.17f, 0f);

    }
}
