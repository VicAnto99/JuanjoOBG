﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Move : MonoBehaviour
{

    public float speed;
    public float speedmove;
    private Rigidbody2D Bod;
    public bool alive;


    void Start()
    {
        Bod = GetComponent<Rigidbody2D>();
        alive = true;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("You are dead");
        transform.position = new Vector3(-71.22f, -29.17f, 0f);
        alive = false;
        speed = 0;
        speedmove = 0;
    }

    // Update is called once per frame
    void Update()
    {
       
        if (alive == true)
        {
            if (Input.GetKey(KeyCode.Space))
            {
                Vector3 movement = new Vector3(1f, 0f, 0f);
                Bod.velocity = movement * speedmove;
            }
            else
            {
                Vector3 movement = new Vector3(1f, 0f, 0f);
                Bod.velocity = movement * speed;
            }
        }
        else
        {
            Vector3 movement = new Vector3(1f, 0f, 0f);
            Bod.velocity = movement * speed;
        }

    }
}
